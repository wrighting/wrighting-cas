define(
({
	"buttonOk" : "Ok",
	"buttonCancel" : "Ləğv et",
	"buttonSave" : "Saxla",
	"itemClose" : "Bağla"
})
);
