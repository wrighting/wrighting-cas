define(
({
	loadingState: "Carregando...",
	errorState: "Desculpe, ocorreu um erro"
})
);
