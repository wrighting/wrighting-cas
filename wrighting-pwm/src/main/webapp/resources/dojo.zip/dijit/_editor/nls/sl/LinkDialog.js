define(
({
	createLinkTitle: "Lastnosti povezave",
	insertImageTitle: "Lastnosti slike",
	url: "URL:",
	text: "Opis:",
	target: "Cilj:",
	set: "Nastavi",
	currentWindow: "Trenutno okno",
	parentWindow: "Nadrejeno okno",
	topWindow: "Okno na vrhu",
	newWindow: "Novo okno"
})
);
